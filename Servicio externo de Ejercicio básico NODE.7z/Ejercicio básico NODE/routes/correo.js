const express = require('express');
  
let router = express.Router();
var nodemailer = require('nodemailer');
router.post('/', (req, res) => {
  var nodemailer = require('nodemailer');
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'testeonodeangular@gmail.com',
      pass: '12node34'
    }
  });
  var mailOptions = {
    from:  'testeonodeangular@gmail.com',
    to: 'testeonodeangular@gmail.com',
    subject: req.body.subject,
    text: req.body.text,
  };
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
});
module.exports = router;